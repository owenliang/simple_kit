#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static char g_version_buf[1024];
char * __$MODULE_LOWER$___autogen_show_version()
{
	int ret = 0;
	g_version_buf[sizeof(g_version_buf)-1] = 0;

	__$INNER_FILE$__

	return g_version_buf;
}


/* vim: set ts=4 sw=4 sts=4 tw=100 */
