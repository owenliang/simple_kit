#include "__$AUTOGEN_FILE$__"

void __$MODULE_NAME$___version()
{
	__$CALL_EVERYLIB_VERSION$__;
	exit(0);
}

void __$MODULE_NAME$___help()
{
	exit(0);
}

/* vim: set ts=4 sw=4 sts=4 tw=100 */
